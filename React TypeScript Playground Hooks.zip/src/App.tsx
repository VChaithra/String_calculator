// App.tsx
import React from 'react';
import Calculator from './Calculator';

const App: React.FC = () => {
  return (
    <div>
      <Calculator />
    </div>
  );
};

export default App;

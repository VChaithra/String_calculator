export class StringCalculator {
  add(numbers: string): number {
    if (numbers === '') {
      return 0;
    }

    const delimiter = this.getDelimiter(numbers);
    const numberArray = numbers.split(new RegExp(delimiter)).map(Number);

    this.validateNumbers(numberArray);

    return numberArray.reduce((sum, num) => sum + num, 0);
  }

  private getDelimiter(numbers: string): string {
    if (numbers.startsWith('//')) {
      const delimiterIndex = numbers.indexOf('\n');
      return numbers.substring(2, delimiterIndex); // Return custom delimiter
    } else {
      return ',|\n'; // Default delimiters
    }
  }

  private validateNumbers(numbers: number[]): void {
    const negativeNumbers = numbers.filter(num => num < 0);
    if (negativeNumbers.length > 0) {
      throw new Error(`Negative numbers not allowed: ${negativeNumbers.join(', ')}`);
    }
  }
}
